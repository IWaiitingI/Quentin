#ifndef NETWORK_H
#define NETWORK_H

void find_backup_logs_remote(const char *server_address, int server_port, const char *backup_dir);

#endif // NETWORK_H